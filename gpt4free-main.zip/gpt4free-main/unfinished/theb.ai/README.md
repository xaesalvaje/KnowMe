https://chatbot.theb.ai/
to do:
- code refractoring